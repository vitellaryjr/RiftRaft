return {
    ["negative_cards"] = false,
    ["void_pack_rate"] = 2, -- 1 to 5, increments of 20%
    ["allow_buy"] = false,
}